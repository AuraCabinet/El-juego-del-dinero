// Firebase Console > Project settings > General > Your apps > Web app.
// Pega aqui tu firebaseConfig y cambia enabled a true.
window.JUEGO_DINERO_FIREBASE = {
  enabled: false,
  config: {
    apiKey: "",
    authDomain: "",
    projectId: "",
    storageBucket: "",
    messagingSenderId: "",
    appId: ""
  }
};
